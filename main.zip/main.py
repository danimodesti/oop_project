#
# Ana Cristina Silva de Oliveira — 11965630
# Danielle Modesti — 12543544
# Laura Ferré Scotelari — 12543436
# Rebeca Vieira Carvalho — 12543530
# 
# POO — 3o semestre — Professor Delamaro
# 
# Projeto Final - POO
from face_the_movie import *

def main():
    # Jogar `Face the Movie` 
    play_game = FaceTheMovie()

if __name__ == "__main__":
    main() 
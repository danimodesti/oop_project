# oop_project
Repository for the object-oriented programming final project, in which we'll make a simple game, similar to "Guess Who?" (the brazilian version is "Cara a cara"). The player will have to guess the movie instead of 'faces of people', based on simple hints.
